package Gameberry.DTO;

public class CrookedDice implements BaseDice{
    @Override
    public int roll() {
        return 0;
    }
}
