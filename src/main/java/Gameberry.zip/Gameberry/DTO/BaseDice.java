package Gameberry.DTO;

public interface BaseDice {
    int roll();
}
