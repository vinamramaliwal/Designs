package Gameberry.Util;

public interface ThrowStrategy {
    int roll();
}
