package Gameberry.Util;

public class CrookedDiceStrategy implements ThrowStrategy{
    @Override
    public int roll() {
        return 0;
    }
}
