package PhonePeMachineCoding.DTO;

public enum OrderStatus {
    ACCEPTED, REJECTED, CANCELED, EXECUTED, PARTIALLY_EXECUTED;
}
