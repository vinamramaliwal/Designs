package PhonePeMachineCoding.DTO;

public enum OrderType {
        BUY, SELL;
}
